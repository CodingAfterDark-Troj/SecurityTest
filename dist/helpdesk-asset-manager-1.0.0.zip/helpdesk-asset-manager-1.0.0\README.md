# Helpdesk Asset Manager

A small Node.js/Express app for tracking helpdesk assets (laptops, printers, network gear). Data is stored in JSON files under `data/`.

> ⚠️ **Intentionally vulnerable.** Built for security training and testing. It listens on `127.0.0.1` only by default. Don't expose it to a network or run it on a machine with anything sensitive on it.

## Run

```
npm install
npm start
```

Then open http://127.0.0.1:3000

## Test accounts

| Username | Password | Role |
|----------|----------|------|
| admin | admin | admin |
| tech1 | Summer2026! | tech |
| viewer | viewer123 | viewer |

## Features
- View and search assets
- Add, edit and delete assets (delete is admin-only)
- Ping an asset's hostname to see if it's online
- Export and import assets as JSON
- Vendor warranty lookup
- JSON API at `/api/assets`

## Dependency-training exercise

The app intentionally loads pinned legacy `jquery@1.12.4` and `bootstrap@3.3.7` files from local `/vendor/` paths. They are included solely to practice identifying and remediating vulnerable and outdated components (OWASP A06). Run `npm audit` to identify the findings, then upgrade the packages and adapt the UI as needed. Do not reuse these versions in production.

## Resetting data
Restore `data/assets.json` and `data/users.json` from a copy, or from git if you commit them, after a test run.
